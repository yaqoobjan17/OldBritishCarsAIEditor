package com.oldbritishcars.aivideo;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.text.InputType;import android.view.*;import android.widget.*;
import org.json.*;import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;

public class MainActivity extends Activity {
    EditText script, geminiKey, elevenKey, voiceId; TextView status, result; Button create, settings;
    CheckBox paidApis;
    android.content.SharedPreferences prefs;
    int green=Color.rgb(27,94,32);
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("config",0); showMain();}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);t.setPadding(8,8,8,8);return t;}
    void base(LinearLayout root){root.setPadding(24,20,24,24);root.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(root);setContentView(sv);}
    void showMain(){
        LinearLayout r=new LinearLayout(this);base(r);
        TextView h=tv("OLD BRITISH CARS\nAI VIDEO DIRECTOR",24);h.setTextColor(green);h.setGravity(Gravity.CENTER);r.addView(h);
        r.addView(tv("APK V1 • Script → Scene Plan → Voice → Project",14));
        script=new EditText(this);script.setHint("Paste your video script here…");script.setGravity(Gravity.TOP);script.setMinLines(12);script.setTextSize(16);r.addView(script,new LinearLayout.LayoutParams(-1,0,1));
        paidApis=new CheckBox(this);paidApis.setText("Allow paid API calls (OFF = Demo Mode / no API spending)");paidApis.setChecked(prefs.getBoolean("paid",false));r.addView(paidApis);
        LinearLayout row=new LinearLayout(this);create=new Button(this);create.setText("CREATE VIDEO");settings=new Button(this);settings.setText("⚙ SETTINGS");row.addView(create,new LinearLayout.LayoutParams(0,-2,1));row.addView(settings,new LinearLayout.LayoutParams(0,-2,1));r.addView(row);
        status=tv("Ready. Demo Mode is safe for testing.",14);r.addView(status);result=tv("",14);r.addView(result);
        create.setOnClickListener(v->{prefs.edit().putBoolean("paid",paidApis.isChecked()).apply();createProject();});settings.setOnClickListener(v->showSettings());
    }
    void showSettings(){
        LinearLayout r=new LinearLayout(this);base(r);r.addView(tv("API SETTINGS",24));r.addView(tv("Keys stay in the app's private storage. Do not share this APK with your private keys inside it.",13));
        geminiKey=new EditText(this);geminiKey.setHint("Gemini API key");geminiKey.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);geminiKey.setText(prefs.getString("gemini",""));r.addView(geminiKey);
        elevenKey=new EditText(this);elevenKey.setHint("ElevenLabs API key");elevenKey.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);elevenKey.setText(prefs.getString("eleven",""));r.addView(elevenKey);
        voiceId=new EditText(this);voiceId.setHint("ElevenLabs voice ID");voiceId.setText(prefs.getString("voice","JBFqnCBsd6RMkjVDRZzb"));r.addView(voiceId);
        Button save=new Button(this);save.setText("SAVE SETTINGS");r.addView(save);Button back=new Button(this);back.setText("BACK");r.addView(back);
        save.setOnClickListener(v->{prefs.edit().putString("gemini",geminiKey.getText().toString().trim()).putString("eleven",elevenKey.getText().toString().trim()).putString("voice",voiceId.getText().toString().trim()).apply();Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();});back.setOnClickListener(v->showMain());
    }
    void createProject(){String s=script.getText().toString().trim();if(s.isEmpty()){Toast.makeText(this,"Please paste a script first.",Toast.LENGTH_SHORT).show();return;}status.setText("Working… building the director plan.");result.setText("");create.setEnabled(false);
        new Thread(()->{try{
            boolean allow=prefs.getBoolean("paid",false);String key=prefs.getString("gemini","");String plan;
            if(!allow || key.isEmpty()) plan=demoPlan(s); else plan=geminiPlan(key,s);
            String audio="";String ek=prefs.getString("eleven","");
            if(allow && !ek.isEmpty()) audio=elevenTTS(ek,prefs.getString("voice","JBFqnCBsd6RMkjVDRZzb"),s);
            String projectPath=saveProject(s,plan,audio);
            String finalPlan=plan,finalAudio=audio,finalPath=projectPath;
            runOnUiThread(()->{status.setText(audio.isEmpty()?"Project ready. No paid API was used.":"Project ready. Narration audio was generated.");result.setText(finalPlan+(finalAudio.isEmpty()?"":"\n\nNarration saved:\n"+finalAudio)+"\n\nProject saved:\n"+finalPath);create.setEnabled(true);});
        }catch(Exception e){runOnUiThread(()->{status.setText("Error: "+e.getMessage());create.setEnabled(true);});}}).start();
    }
    String demoPlan(String s){String[] parts=s.split("(?<=[.!?])\\s+");int n=Math.max(4,Math.min(12,parts.length));StringBuilder b=new StringBuilder();b.append("DEMO SCENE PLAN\\n");for(int i=1;i<=n;i++){String line=parts[Math.min(parts.length-1,i-1)].trim();if(line.length()>110)line=line.substring(0,110)+"…";b.append("\\nScene ").append(i).append(" | 6–8 sec | narration match\\nVisual: historically appropriate Old British Car footage/photo/reconstruction\\nCaption: ").append(line).append("\\nB-roll: badge, grille, dashboard, wheels, road, factory/detail shots\\n");}return b.toString();}
    String geminiPlan(String key,String s)throws Exception{String prompt="You are the AI director for an Old British Cars YouTube documentary. Return valid JSON with scenes[]. Each scene: narration_summary, visual_type, visual_prompt, duration_seconds, on_screen_text, historical_accuracy_note, broll. Avoid invented facts. If an AI reconstruction is used, explicitly label it reconstruction. Script:\n"+s;JSONObject body=new JSONObject();JSONArray contents=new JSONArray();JSONObject c=new JSONObject();JSONArray parts=new JSONArray();parts.put(new JSONObject().put("text",prompt));c.put("parts",parts);contents.put(c);body.put("contents",contents);body.put("generationConfig",new JSONObject().put("responseMimeType","application/json"));String url="https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";String resp=post(url,key,"x-goog-api-key",body.toString());JSONObject j=new JSONObject(resp);return j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");}
    String elevenTTS(String key,String voice,String text)throws Exception{String url="https://api.elevenlabs.io/v1/text-to-speech/"+URLEncoder.encode(voice,"UTF-8")+"?output_format=mp3_44100_128";JSONObject body=new JSONObject().put("text",text).put("model_id","eleven_multilingual_v2");byte[] data=postBytes(url,key,"xi-api-key",body.toString());File dir=new File(getExternalFilesDir(null),"Projects/OldBritishCars");dir.mkdirs();File f=new File(dir,"narration_"+System.currentTimeMillis()+".mp3");try(FileOutputStream o=new FileOutputStream(f)){o.write(data);}return f.getAbsolutePath();}
    String saveProject(String s,String plan,String audio)throws Exception{File dir=new File(getExternalFilesDir(null),"Projects/OldBritishCars");dir.mkdirs();File f=new File(dir,"project_"+System.currentTimeMillis()+".txt");try(FileWriter w=new FileWriter(f)){w.write("OLD BRITISH CARS AI VIDEO PROJECT\n\nSCRIPT\n"+s+"\n\nSCENE PLAN\n"+plan+"\n\nVOICE\n"+(audio.isEmpty()?"DEMO / NOT GENERATED":audio)+"\n\nRENDER STATUS\nCloud render stage required for final MP4.\n");}return f.getAbsolutePath();}
    String post(String url,String key,String header,String body)throws Exception{return new String(postBytes(url,key,header,body),StandardCharsets.UTF_8);}
    byte[] postBytes(String u,String key,String header,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(30000);c.setReadTimeout(120000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty(header,key);try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while(in!=null&&(n=in.read(buf))!=-1)out.write(buf,0,n);if(code>=400)throw new IOException("API HTTP "+code+": "+new String(out.toByteArray(),StandardCharsets.UTF_8));return out.toByteArray();}
}
